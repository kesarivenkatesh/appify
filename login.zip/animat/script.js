document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById('loginForm');

    // Login form slide-in animation
    setTimeout(() => {
        loginForm.style.animation = 'slideIn 1s forwards';
    }, 2000);
});